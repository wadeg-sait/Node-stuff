var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "harv",
  password: "password",
  database: "travelexperts"
});

con.connect(function(err) {
  if (err) throw err;
  var sql = "DELETE FROM customers WHERE customerId = ?";
  con.query(sql, [106], function (err, result) {
    if (err) throw err;
    console.log("Number of records deleted: " + result.affectedRows);
	con.end(function(err) {
	  if (err) throw err;
	});
  });
});