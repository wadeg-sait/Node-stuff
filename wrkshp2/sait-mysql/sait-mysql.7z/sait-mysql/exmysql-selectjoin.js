var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "harv",
  password: "password",
  database: "travelexperts"
});

con.connect(function(err) {
  if (err) throw err;
  var sql = "SELECT customers.CustFirstName, customers.CustLastName, bookings.BookingNo"
    + " FROM customers JOIN bookings ON customers.CustomerId = bookings.CustomerId";
  con.query(sql, function (err, result, fields) {
    if (err) throw err;
    console.log(result);
	con.end(function(err) {
	  if (err) throw err;
	});
  });
});