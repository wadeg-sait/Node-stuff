var mysql = require('mysql');

var con = mysql.createConnection({
  host: "localhost",
  user: "harv",
  password: "password",
  database: "travelexperts"
});

con.connect(function(err) {
  if (err) throw err;
  var sql = "UPDATE customers SET CustAddress = ?, CustHomePhone= ? WHERE CustomerId = ?";
  con.query(sql, [ '23 4th St.', '403-555-5555', 106], function (err, result) {
    if (err) throw err;
    console.log(result.affectedRows + " record(s) updated");
	con.end(function(err) {
	  if (err) throw err;
	});
  });
});