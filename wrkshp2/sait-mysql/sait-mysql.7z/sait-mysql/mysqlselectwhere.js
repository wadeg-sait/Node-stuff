const mysql = require("mysql");

var conn = mysql.createConnection({
	host: "localhost",
	user: "harv",
	password: "password",
	database: "travelexperts"
});

conn.connect((err)=>{
	if (err) throw err;
	var sql = "SELECT CustFirstName, CustLastName FROM customers WHERE CustomerId = ?";
	var data = [ 106 ];
	conn.query(sql, data, (err, result, fields)=>{
		if (err) throw err;
		console.log(result);
		conn.end((err)=>{
			if (err) throw err;
		});
	});
});